# THSL Guru Discord Hockey Card Bot

This project contains a Python Discord hockey-card bot at the repository root
alongside the existing pnpm workspace artifacts. Preserve both parts of the
workspace.

## Run & Operate

- `python main.py` — start the Discord bot; requires `DISCORD_BOT_TOKEN` in Secrets
- `python -m unittest discover -s tests -v` — run offline bot tests
- `pnpm run typecheck` — typecheck the existing TypeScript workspace
- `DISCORD_GUILD_ID` — optional development guild for fast slash-command sync
- `BOT_DATABASE_PATH` — optional path for the persistent SQLite database

## Stack

- Bot: Python 3.10+, discord.py 2.x, SQLite, ImageMagick for lineup rendering
- Existing workspace: pnpm, Node.js 24, TypeScript 5.9, Express, Drizzle

## Where things live

- `main.py` — bot startup, extensions, and command sync
- `commands/` — slash-command extensions and shared card formatting
- `database.py` — SQLite schema and transactional economy operations
- `data/players.json` — initial player card catalog
- `data/guru.sqlite3` — runtime database; ignored by Git
- `cards/` — uploaded card images such as `cards/dan.png`
- `tests/` — tests using temporary database files

## Architecture decisions

- The bot is independent of the existing web/API artifacts and can run as a
  long-lived worker.
- Economy writes use SQLite `BEGIN IMMEDIATE` transactions to serialize claims,
  sales, grants, and pack purchases.
- Lineup, substitute, and formation migrations are additive; never reset or
  replace existing player, balance, inventory, or starting-lineup rows.
- The uploaded older bot's JSON balances and inventories are not imported into
  the new SQLite economy. Do not migrate them without explicit approval.
- Seed records are inserted only when missing so administrator edits persist.

## Product

Discord users can collect hockey player cards, claim coins, browse and buy
rarity-specific packs, manage inventories, view a generated LW/RW/GK rink
lineup with two substitute slots, and choose a tactical formation.
Administrators can manage the card catalog and grant balances or cards.

## User preferences

- Do not generate a replacement image for Dan. If `cards/dan.png` is missing,
  commands should show the card details and explain where to upload the image.

## Gotchas

- The seeded catalog contains one GOLD and two TOTW cards. Pack odds should
  always be derived from eligible catalog records, and unavailable packs must
  never charge users.
- Never put the Discord token in source, logs, or chat. Use the rotated token in
  Secrets; a token included in the supplied brief must be revoked.
- Discord slash-command sync and login cannot be verified until a valid token is
  configured.

## Pointers

- See the `pnpm-workspace` skill for workspace structure, TypeScript setup, and package details
